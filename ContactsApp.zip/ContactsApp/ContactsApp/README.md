# Contacts App
 Contacts App directed to students of Udacity it stores the contacts (student name - email) so that the student can log in by using Udacity account and view the contacts stored in without the need for Internet
 # App functionalities
 ### Log in ViewController
 A user can log in by using Udacity account if the account is correct he/she will access to the app, if not the alert will show for him/her
 ### TabelViewController
 A user can add a contact with a photo from the library and the user can see contacts information in a table view, this photo added it's presented with the contact information. 
 # Tools
 * Core data
 * UITableViewController
 * Udacity API 
 # Requirements
 * Xcode 10
 * Swift 4 
 * Udacity account
 # Build and run

 * Downloaded zip file.
 
 * Navigate inside the unzipped folder.
 
 * Click on the file labeled ContactsApp.xcodeProject
 
 * If a warning dialog appears, click on Open Anyway
 
 * Simultaneously press Command + B to run


