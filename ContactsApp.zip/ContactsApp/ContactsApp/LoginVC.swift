//
//  LoginVC.swift
//  ContactsApp
//
//  Created by Ebtehal 🕸 on 21/03/1440 AH.
//  Copyright © 1440 Ebtehal 🕸. All rights reserved.
//

import Foundation
import UIKit

class LoginVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        emailField.text = ""
        passwordField.text = ""
    self.activityIndicator.isHidden = true
    }
  
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var logeInButton: UIButton!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    
    @IBAction func logInAction(_ sender: Any) {
        loginStartActiv(start: true)
        guard let email = emailField.text?.trimmingCharacters(in: .whitespaces),
            let password = passwordField.text?.trimmingCharacters(in: .whitespaces),
            !email.isEmpty, !password.isEmpty
            else {
                alert(title: "Waring", message: "enter your email")
                update(start: false)
                return
        }
        
        Udacity.postSession(with: email, password: password) { (errString) in
            
            guard errString == nil else {
                self.alert(title: "Error", message: errString!)
                self.update(start: false)
                return
            }
            self.update(start: false)
            DispatchQueue.main.async {
                self.emailField.text = ""
                self.passwordField.text = ""
                self.performSegue(withIdentifier: "tapsegue", sender: self)
            }
        }
        self.update(start: true)
        
        
        
    }
    func update(start: Bool) {
        DispatchQueue.main.async {
            self.emailField.isUserInteractionEnabled = !start
            self.passwordField.isUserInteractionEnabled = !start
            self.logeInButton.isEnabled = !start
            self.activityIndicator.isHidden = !start
            if start {
                self.activityIndicator.startAnimating()
            } else {
                self.activityIndicator.stopAnimating()
            }
            
        }
        
    }
    
    func loginStartActiv(start : Bool) {
        emailField.isUserInteractionEnabled = start
        passwordField.isUserInteractionEnabled = start
        activityIndicator.isHidden = start
        if start {
            activityIndicator.startAnimating()
        } else {
            activityIndicator.stopAnimating()
        }
    }
}

extension UIViewController {
    
    func alert(title: String?, message: String?) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
        DispatchQueue.main.async {
            self.present(alert, animated: true, completion: nil)
        }}
}


