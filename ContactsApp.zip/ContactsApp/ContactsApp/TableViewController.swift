//
//  TableViewController.swift
//  ContactsApp
//
//  Created by Ebtehal 🕸 on 21/03/1440 AH.
//  Copyright © 1440 Ebtehal 🕸. All rights reserved.
//

import UIKit
import CoreData

class TableViewController: UITableViewController ,UINavigationControllerDelegate , UIImagePickerControllerDelegate {
    
        var managedObjextContext:NSManagedObjectContext!
        var contacts = [Contact]()

    override func viewDidLoad() {
        super.viewDidLoad()
     managedObjextContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        loadData()
    }
    func loadData(){
        let contactsRequest:NSFetchRequest<Contact> = Contact.fetchRequest()
        
        do {
            contacts = try managedObjextContext.fetch(contactsRequest)
            self.tableView.reloadData()
        }catch {
            print("Could not load data from database \(error.localizedDescription)")
        }
        
    }
    @IBAction func addContacts(_ sender: Any) {
        let imgePiker = UIImagePickerController()
        imgePiker.sourceType = .photoLibrary
        imgePiker.delegate = self
        self.present(imgePiker, animated: true, completion: nil)

        
    }
    @IBAction func logoutAction(_ sender: Any) {
        Udacity.deleteSession { (error) in
            if let error = error {
                self.alert(title: "Error", message: error.localizedDescription)
                return
            }
            DispatchQueue.main.async {
                self.dismiss(animated: true, completion: nil)
            }
        }
    }
    func createContacts (with image:UIImage) {
        
        let contacts = Contact(context: managedObjextContext)
        contacts.image = image.jpegData(compressionQuality: 0.3)
        
        
        let inputAlert = UIAlertController(title: "New Contact", message: "Enter a contact name and a contact Email.", preferredStyle: .alert)
        inputAlert.addTextField { (textfield:UITextField) in
            textfield.placeholder = "Contact Name "
        }
        inputAlert.addTextField { (textfield:UITextField) in
            textfield.placeholder = "Contact Email"
        }
        
        inputAlert.addAction(UIAlertAction(title: "Save", style: .default, handler: { (action:UIAlertAction) in
            
            let personTextField = inputAlert.textFields?.first
            let emailtTextField = inputAlert.textFields?.last
            
            if personTextField?.text != "" && emailtTextField?.text != "" {
                contacts.person = personTextField?.text
                contacts.email = emailtTextField?.text
                
                do {
                    try self.managedObjextContext.save()
                    self.loadData()
                }catch {
                    print("Could not save data \(error.localizedDescription)")
                }
                
            }
            
            
        }))
        
        inputAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(inputAlert, animated: true, completion: nil)
        
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {

        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            picker.dismiss(animated: true, completion: {
                self.createContacts(with: image)
            })
        }
        
        
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return contacts.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCell
       let list = contacts[indexPath.row]
       if let contactImage = UIImage(data: list.image as! Data) {
        cell.backgroundImageView.image = contactImage
        }
        cell.nameLabel.text = list.person
        cell.emailLabel.text = list.email
     return cell
  }
 

    
    
}
